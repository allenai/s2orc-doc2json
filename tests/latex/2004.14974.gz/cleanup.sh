rm *.aux *.bbl *.blg *.fdb_latexmk *.fls *.log *.out
